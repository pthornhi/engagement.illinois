var timeline1865 = ["charterday.html", "charterday-next.html", "charterday-testing.html", "charterday-last.html"];
var timeline1875 = ["historypage1.html", "historypage3.html", "historypage3.html"];