NOTE: To use these examples, you must run a simple local webserver. They WILL NOT work if you simply open them in a browser from the file system.

If you have python installed, here are simple steps to do this.

1. Open a terminal shell
1. Make sure you are in the "root" directory that you checked out from GitHub
1. Type `python -m SimpleHTTPServer 8000`
1. in your web browser, open `http://localhost:8000/examples/example_json.html` (or whatever other file you want to see
)

